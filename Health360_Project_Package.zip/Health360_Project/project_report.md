# Health360 Project Report

## 1. Abstract
Health360 demonstrates how Tableau-style visual analytics can organize patient-like data and make patterns across demographic, clinical, symptom, and lifestyle variables easier to explore. The package contains 600 synthetic records and an illustrative rule-based risk label.

## 2. Problem statement
Reviewing many records manually can make it difficult to compare indicators and communicate possible patterns. A dashboard can summarize the data, allow filtering, and help users explore which groups have more flagged indicators.

## 3. Objectives
- Summarize the distribution of illustrative risk categories.
- Compare risk categories across age groups and lifestyle factors.
- Explore relationships among BMI, systolic blood pressure, cholesterol, and glucose.
- Build an interactive dashboard and a short story for communicating findings.
- Clearly document limitations and responsible interpretation.

## 4. Data and methodology
The dataset contains 600 synthetic records and fields for age, BMI, systolic blood pressure, cholesterol, glucose, lifestyle categories, symptoms, and a rule-based score. Records were generated for demonstration only. The scoring thresholds and weights are simple, arbitrary teaching rules and have not been clinically validated.

## 5. Illustrative summary
- Total synthetic records: 600
- Low category: 397 (66.2%)
- Moderate category: 166 (27.7%)
- High category: 37 (6.2%)
- Average age: 49.0 years
- Average BMI: 26.4

These values describe the generated demo dataset only and must not be generalized to any real population.

## 6. Expected dashboard insights
The dashboard allows viewers to compare the synthetic risk labels across age bands, lifestyle categories, and clinical indicators. The scatter plot can help visualize how BMI and blood pressure are distributed across labels. Filters make it possible to inspect subsets without manually editing the source file.

## 7. Limitations
- Data are entirely synthetic.
- The risk score is illustrative and not a diagnostic or predictive model.
- Correlation does not establish causation.
- The dataset does not represent any particular hospital, region, or patient population.
- Real-world use would require expert review, validated methods, privacy safeguards, and appropriate clinical governance.

## 8. Conclusion
Health360 provides a beginner-friendly foundation for a healthcare analytics dashboard and story. It demonstrates data preparation, visualization planning, filtering, and responsible reporting while avoiding claims about real patients or clinical performance.

## 9. Tools
- Tableau Public / Tableau Desktop (to build the interactive workbook)
- CSV dataset
- HTML preview for quick review
