# Health360: Comprehensive Healthcare Risk & Disease Analysis

## Project overview
Health360 is a data-visualization project that explores how demographic, clinical, and lifestyle indicators vary across illustrative patient records. It is designed as a learning/demo project for Tableau dashboards and storytelling.

## Important data notice
**Every row in the included dataset is synthetic and generated for demonstration.** It is not real patient data and must not be used for diagnosis, treatment, or clinical decisions. The risk category is a simple illustrative rule-based label, not a validated medical model.

## Files
- `health360_synthetic_dataset.csv` — 600 synthetic records for Tableau.
- `tableau_build_guide.md` — worksheet, dashboard, and story instructions.
- `project_report.md` — problem statement, method, findings, limitations, and conclusion.
- `dashboard_preview.html` — a local, self-contained preview of summary charts.

## How to use in Tableau
1. Open Tableau Public or Tableau Desktop.
2. Choose **Connect → To a File → Text file** and select `health360_synthetic_dataset.csv`.
3. Check field types: Patient_ID and categorical fields as dimensions; Age, BMI, BP, Cholesterol, Glucose, and Illustrative_Risk_Score as measures.
4. Build the worksheets described in `tableau_build_guide.md`.
5. Add filters for Risk_Category, age group, Smoking_Status, and Exercise_Level.
6. Create a dashboard and a story point with the key findings.
7. If submitting, include screenshots or a published Tableau link only after you have actually created/published the workbook.

## Suggested project objective
Use interactive visualizations to explore patterns in synthetic health indicators, identify groups with more flagged indicators under a transparent illustrative scoring rule, and communicate preventive-care questions that could be explored with properly governed real-world data.

## How the risk category is assigned
The illustrative score adds points for selected threshold flags: age ≥ 60 (+2), BMI ≥ 30 (+1), systolic blood pressure ≥ 140 (+2), cholesterol ≥ 240 mg/dL (+2), glucose ≥ 126 mg/dL (+2), current smoking (+1), high alcohol category (+1), low exercise (+1), fatigue (+1), chest pain (+2), and dizziness (+1). Categories: Low (score < 4), Moderate (4–6), High (≥ 7). These are arbitrary demo rules, not medical guidance.
