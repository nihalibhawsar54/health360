# Tableau Build Guide

## Recommended worksheets
1. **Risk Category Distribution** — bar chart; Rows: `Risk_Category`; Columns: Number of Records; sort descending.
2. **Risk by Age Group** — create calculated field `Age Group`:
   ```
   IF [Age] < 30 THEN "18–29"
   ELSEIF [Age] < 45 THEN "30–44"
   ELSEIF [Age] < 60 THEN "45–59"
   ELSE "60+"
   END
   ```
   Use `Age Group` on Columns, `Risk_Category` on Color, Number of Records on Rows.
3. **BMI vs Systolic BP** — scatter plot; Columns: `BMI`; Rows: `Systolic_BP_mmHg`; Color: `Risk_Category`; detail: `Patient_ID`.
4. **Clinical Indicator Comparison** — create a measure or use separate sheets to show average cholesterol and glucose by risk category.
5. **Lifestyle Breakdown** — stacked bar charts for `Smoking_Status`, `Alcohol_Consumption`, and `Exercise_Level`, colored by `Risk_Category`.
6. **Symptom Flags** — compare counts of `Fatigue`, `Chest_Pain`, and `Dizziness` by risk category.

## Dashboard layout
- Top KPI tiles: Total Records, High Risk Count, High Risk %, Average Age.
- Middle row: Risk Category Distribution and Risk by Age Group.
- Bottom row: BMI vs Systolic BP scatter plot and Lifestyle Breakdown.
- Add filter cards for `Risk_Category`, `Age Group`, `Smoking_Status`, and `Exercise_Level`.
- Use consistent colors: Low = green, Moderate = amber, High = red; use accessible contrast and labels.
- Add a subtitle: “Synthetic educational data — not for clinical use.”

## Suggested Tableau Story
1. **Overview:** distribution of illustrative risk categories.
2. **Who is flagged?** compare categories across age groups.
3. **Clinical indicators:** explore BP, cholesterol, glucose, and BMI patterns.
4. **Lifestyle context:** examine smoking, alcohol, and exercise categories.
5. **Takeaway:** these synthetic patterns demonstrate how dashboards can support exploration; real clinical use requires validated models, data governance, and expert review.

## Quality checks
- Confirm record count is 600.
- Confirm no blank values in the generated dataset.
- Check chart titles, axis units, and tooltip labels.
- Test filters and dashboard actions.
- Do not describe the categories as actual disease diagnoses.
